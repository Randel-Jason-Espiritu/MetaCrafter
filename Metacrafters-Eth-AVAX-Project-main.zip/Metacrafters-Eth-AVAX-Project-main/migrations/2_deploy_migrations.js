var Project1 = artifacts.require("FunctionsAndErrorHandling");
module.exports = function(deployer) {
  deployer.deploy(Project1);
}

